import React from 'react';

function SearchByName() {
  return (
    <div>Search by name</div>
  );
}

export default SearchByName;
