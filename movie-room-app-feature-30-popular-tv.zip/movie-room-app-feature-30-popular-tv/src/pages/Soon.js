import React from 'react';

function Soon() {
  return (
    <div>Soon</div>
  );
}

export default Soon;
