import React from 'react';

function Videos() {
  return (
    <div>Videos</div>
  );
}

export default Videos;
