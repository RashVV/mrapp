import React from 'react';

function AllMovies() {
  return (
    <div>All movies</div>
  );
}

export default AllMovies;
