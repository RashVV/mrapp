import React from 'react';

function News() {
  return (
    <div>News</div>
  );
}

export default News;
