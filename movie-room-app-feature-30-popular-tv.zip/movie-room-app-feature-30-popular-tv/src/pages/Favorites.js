import React from 'react';

function Favorites() {
  return (
    <div>Favorites</div>
  );
}

export default Favorites;
