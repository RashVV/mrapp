import React from 'react';

function Premieres() {
  return (
    <div>Premieres</div>
  );
}

export default Premieres;
