import React from 'react';

function Recommendations() {
  return (
    <div>Recommendations</div>
  );
}

export default Recommendations;
