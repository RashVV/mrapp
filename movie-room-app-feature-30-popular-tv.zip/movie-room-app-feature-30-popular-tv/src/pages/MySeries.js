import React from 'react';

function MySeries() {
  return (
    <div>My serials</div>
  );
}

export default MySeries;
