import React from "react";

export function MoviesPage() {
  return (
    <div className="App">
      <p>Movies</p>
    </div>
  );
}
