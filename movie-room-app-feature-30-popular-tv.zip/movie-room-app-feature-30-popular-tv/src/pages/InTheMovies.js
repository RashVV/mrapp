import React from 'react';

function InTheMovies() {
  return (
    <div>In the movies</div>
  );
}

export default InTheMovies;
