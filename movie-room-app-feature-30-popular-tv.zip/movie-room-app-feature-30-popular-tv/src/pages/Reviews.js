import React from 'react';

function Reviews() {
  return (
    <div>Reviews</div>
  );
}

export default Reviews;
