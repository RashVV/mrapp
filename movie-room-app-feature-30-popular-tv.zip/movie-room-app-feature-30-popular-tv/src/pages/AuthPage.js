import React from "react";

export function AuthPage () {
  return (
    <div className="App">
      <p>Authorization</p>
    </div>
  );
}
