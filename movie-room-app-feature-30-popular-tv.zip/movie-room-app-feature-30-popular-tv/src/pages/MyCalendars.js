import React from 'react';

function MyCalendars() {
  return (
    <div>My calendars</div>
  );
}

export default MyCalendars;
