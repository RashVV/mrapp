import React from 'react';

function Online() {
  return (
    <div>Online</div>
  );
}

export default Online;
