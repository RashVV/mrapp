import React from 'react';

function Tape() {
  return (
    <div>Tape</div>
  );
}

export default Tape;
