import React from 'react';

function Friends() {
  return (
    <div>Friends</div>
  );
}

export default Friends;
