export const config = {
  api_key: "9251239416670b65560380af81da5b8c",
  api_base_url: "https://api.themoviedb.org/3/",
  api_img_url: "https://image.tmdb.org/t/p/"
};
