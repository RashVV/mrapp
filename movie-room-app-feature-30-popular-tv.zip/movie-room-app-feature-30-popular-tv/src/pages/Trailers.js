import React from 'react';

function Trailers() {
  return (
    <div>Trailers</div>
  );
}

export default Trailers;
